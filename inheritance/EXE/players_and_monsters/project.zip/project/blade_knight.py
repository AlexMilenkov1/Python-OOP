from project.knight import Knight


class BladeKnight(Knight):
    pass
