from project.wizard import Wizard


class SoulMaster(Wizard):
    pass
