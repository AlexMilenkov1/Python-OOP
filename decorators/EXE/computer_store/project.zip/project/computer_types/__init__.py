class ComputerStoreApp:
    pass